<?php

return [
    'extends' => 'radio'
];
