<?php

return [
    'save' => false,
    'props' => [
        'numbered' => function (bool $numbered = true) {
            return $numbered;
        }
    ]
];
